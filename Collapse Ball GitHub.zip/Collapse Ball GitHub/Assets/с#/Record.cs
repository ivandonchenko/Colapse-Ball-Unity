using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Record : MonoBehaviour
{
    public int score;
    public int record;
    public Text recordText;

    void Start()
    {
        score = PlayerPrefs.GetInt("Score");
        record = PlayerPrefs.GetInt("Record");
        recordText.text = record.ToString();
        PlayerPrefs.SetInt("Record", record);
    }

    /*void Update()
    {
        
        if (PlayerPrefs.GetInt("Score") >= PlayerPrefs.GetInt("Record"))
        {
            PlayerPrefs.SetInt("Record", score);
            recordText.text = record.ToString();
            record = PlayerPrefs.GetInt("Record");
        }
        else
        {
            recordText.text = record.ToString();
        }
    }*/
}
