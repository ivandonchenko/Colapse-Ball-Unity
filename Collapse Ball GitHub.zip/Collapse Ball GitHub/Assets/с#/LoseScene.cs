using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LoseScene : MonoBehaviour
{
    public int score;
    public int scoreMoney;
    public Text scoreText;
    public Text scoreTextMoney;
    public int money;

    void Start()
    {
        score = PlayerPrefs.GetInt("Score");
        scoreMoney = PlayerPrefs.GetInt("Score Money");
        money = PlayerPrefs.GetInt("Money");
        money += scoreMoney;
        PlayerPrefs.SetInt("Money", money);
        scoreMoney = 0;
        PlayerPrefs.SetInt("Score Money", scoreMoney);
    }

    void Update()
    {
        scoreText.text = score.ToString();
        scoreTextMoney.text = money.ToString();
    }

    public void ToMenu()
    {
        SceneManager.LoadScene(0);
        PlayerPrefs.SetInt("Score", score);
    }
}
