using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    public int money;
    public int earnedMoney;
    [SerializeField] Text moneyText;
    public int record;
    [SerializeField] Text recordText;
    [SerializeField] GameObject newRecordText;
    public int score;
    public GameObject settings;
    public GameObject deletePanel;
    [SerializeField] public AudioSource audioSource;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        score = PlayerPrefs.GetInt("Score");
        record = PlayerPrefs.GetInt("Record");
        recordText.text = record.ToString();
        
        money = PlayerPrefs.GetInt("Money");
        earnedMoney = PlayerPrefs.GetInt("Score Money");
        money += earnedMoney;
        PlayerPrefs.SetInt("Money", money);
        moneyText.text = money.ToString();
        earnedMoney = 0;
        PlayerPrefs.SetInt("Score Money", earnedMoney);
    }
    private void Update()
    {
        if (score > record)
        {
            record = score;
            recordText.text = record.ToString();
            newRecordText.SetActive(true);
            PlayerPrefs.SetInt("Record", score);

        }
    }
    
    public void SettingsOn()
    {
        settings.SetActive(true);
        audioSource.Play();
    }

    public void SettingsOff()
    {
        settings.SetActive(false);
        audioSource.Play();
    }

    public void DeletePanelOn()
    {
        deletePanel.SetActive(true);
        audioSource.Play();
    }

    public void DeletePanelOff()
    {
        deletePanel.SetActive(false);

        audioSource.Play();
    }

    public void GoShop()
    {
        SceneManager.LoadScene(3);

        audioSource.Play();
    }

    public void SoundGo()
    {
        audioSource.Play();
    }

    public void StartGame()
    {
        SceneManager.LoadScene(1);
    }
}
