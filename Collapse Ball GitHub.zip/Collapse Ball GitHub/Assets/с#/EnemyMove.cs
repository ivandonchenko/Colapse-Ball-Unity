using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMove : MonoBehaviour
{
    [SerializeField] GameObject enemy;
    [SerializeField] float speed;
    
    private void FixedUpdate()
    {
        if (PlayerPrefs.GetInt("Score") <= 25)
        {
            enemy.transform.Translate(speed * Time.deltaTime, 0, 0);
        }
        else if (PlayerPrefs.GetInt("Score") > 25 && PlayerPrefs.GetInt("Score") <= 50)
        {
            enemy.transform.Translate(speed * 1.2f * Time.deltaTime, 0, 0);
        }
        else if (PlayerPrefs.GetInt("Score") > 50 && PlayerPrefs.GetInt("Score") <= 100)
        {
            enemy.transform.Translate(speed * 1.4f * Time.deltaTime, 0, 0);
        }
        else if(PlayerPrefs.GetInt("Score") > 100)
        {
            enemy.transform.Translate(speed * 1.65f * Time.deltaTime, 0, 0);
        }
        
    }
}
