using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ShopAssist : MonoBehaviour
{
    public int money;
    [SerializeField] Text moneyText;
    public bool isMulti;
    [SerializeField] public AudioSource audioSource;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        isMulti = PlayerPrefs.GetInt("isMulti") == 1 ? true : false;
        PlayerPrefs.GetInt("Money");
    }

    void Update()
    {

        money = PlayerPrefs.GetInt("Money");
        moneyText.text = money.ToString();   
    }

    public void BuyMulti()
    {
        audioSource.Play();
        if (money >= 10
            && isMulti == false)
        {
            isMulti = true;
            money -= 10;
            PlayerPrefs.SetInt("Money", money);
            PlayerPrefs.SetInt("isMulti", isMulti ? 1 : 0);
        }
    }
    public void ExitShopSound()
    {
        audioSource.Play();
    }

    public void ExitShop()
    {
        
        SceneManager.LoadScene(0);
    }
}
