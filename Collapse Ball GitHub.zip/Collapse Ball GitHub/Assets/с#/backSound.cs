using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class backSound : MonoBehaviour
{
    public void Start()
    {
        PlayerPrefs.GetInt("SoundOffOn");
    }

    public void Update()
    {
        if (PlayerPrefs.GetInt("SoundOffOn") == 1)
        {
            AudioListener.volume = 1;
            PlayerPrefs.SetInt("SoundOffOn", 1);
        }
        else if(PlayerPrefs.GetInt("SoundOffOn") == 0)
        {
            AudioListener.volume = 0;
            PlayerPrefs.SetInt("SoundOffOn", 0);
        }
    }

    public void SoundOn()
    {
        AudioListener.volume = 1;
        PlayerPrefs.SetInt("SoundOffOn", 1);
    }

    public void SoundOff()
    {
        AudioListener.volume = 0;
        PlayerPrefs.SetInt("SoundOffOn", 0);
    }
}
