using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GoScripts : MonoBehaviour
{
    public int score;
    public bool isMulti;
    public int scoreMoney;
    [SerializeField] Text scoreText;
    [SerializeField] GameObject ball;
    [SerializeField] GameObject spawn;
    [SerializeField] Text scoreTextMoney;
    public GameObject bonusEffect;
    [SerializeField] AudioSource coinSound;
    [SerializeField] AudioSource loseSound;

    public void Start()
    {
        /*coinSound = GetComponent<AudioSource>();
        loseSound = GetComponent<AudioSource>();*/
        PlayerPrefs.SetInt("Score", 0);
        isMulti = PlayerPrefs.GetInt("isMulti") == 1 ? true : false;
        StartCoroutine(ScorePlus());
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag == "Bonus")
        {

            coinSound.Play();
            Destroy(other.gameObject);
            Instantiate(bonusEffect, transform.position, Quaternion.identity);
            if (isMulti == true)
            {
                scoreMoney+=2;
            }
            else
            {
                scoreMoney++;
            }
            
            PlayerPrefs.SetInt("Score Money", scoreMoney);
        }
        else if (other.gameObject.tag == "Vrag")
        {
            PlayerPrefs.SetInt("Score", score);
            Destroy(other);
            SceneManager.LoadScene(2);
            Destroy(ball.gameObject);
            Destroy(spawn.gameObject);
        }

    }

    IEnumerator ScorePlus()
    {
        yield return new WaitForSeconds(1.5f);
        score++;
        Repeat();
    }

    void Update()
    {
        scoreText.text = score.ToString();
        scoreTextMoney.text = scoreMoney.ToString();
        PlayerPrefs.SetInt("Score", score);
    }

    void Repeat()
    {
        StartCoroutine(ScorePlus());
    }
}
